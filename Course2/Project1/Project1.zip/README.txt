

S3 URL: http://my-project1-bucket.s3-website.eu-central-1.amazonaws.com/
CloudFront URL: https://dfmil37rp63r0.cloudfront.net/


